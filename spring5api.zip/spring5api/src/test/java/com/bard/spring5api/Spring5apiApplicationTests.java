package com.bard.spring5api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring5apiApplicationTests {

	@Test
	void contextLoads() {
	}

}
