package com.bard.spring5api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring5apiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring5apiApplication.class, args);
	}

}
